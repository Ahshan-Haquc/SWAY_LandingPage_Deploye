"use client";

import React, { useState } from "react";

const LIGHT_BG = "#D9E7FE";
const ACTIVE_BG = "#FAEFB8";

const PricingCartPriceToggle = ({pricingName}:{pricingName: string}) => {
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "annual" | null>(null);

  return (
    <div className="w-full max-w-md mx-auto p-4">

      {/* === 6. Monthly/Annual Toggle === */}
      <div
        className="flex w-full text-sm font-semibold mb-4 rounded-full overflow-hidden shadow-lg p-2"
        style={{ backgroundColor: LIGHT_BG }}
      >
        <div
          className={`w-1/2 py-3 rounded-full text-center cursor-pointer duration-300 hover:bg-[#FF6464] ${
            selectedPlan === "monthly" ? "bg-[#FAEFB8]" : ""
          }`}
          style={{ color: "black" }}
          onClick={() => setSelectedPlan("monthly")}
        >
          MONTHLY £
        </div>
        <div
          className={`w-1/2 py-3 rounded-full text-center cursor-pointer duration-300 hover:bg-[#FF6464] ${
            selectedPlan === "annual" ? "bg-[#FAEFB8]" : ""
          }`}
          style={{ color: "black" }}
          onClick={() => setSelectedPlan("annual")}
        >
          ANNUAL £
        </div>
      </div>
      <p className="text-xs font-light mb-4">Minimum membership {pricingName==="CORE" ? "4" : "6"} months</p>
    {selectedPlan && (
        <>

      {/* === 7. Price Boxes === */}
      <div className="flex w-full justify-between space-x-4">

        {/* Monthly Price Box */}
        <div
          className="w-1/2 p-2 lg:p-4 flex flex-col items-start rounded-lg cursor-pointer transition-all duration-300"
          style={{
            backgroundColor: selectedPlan === "monthly" ? ACTIVE_BG : LIGHT_BG,
            color: "black",
          }}
          onClick={() => setSelectedPlan("monthly")}
        >
          <div className="flex items-center space-x-1 mb-1">
            <div className="w-4 h-4 rounded-full border border-black flex items-center justify-center">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: selectedPlan === "monthly" ? "#FF6464" : LIGHT_BG,}}></div>
            </div>
            <span className="text-xs xl:text-sm font-bold">MONTHLY</span>
          </div>
          <p className="text-lg xl:text-2xl font-bold">£1050</p>
        </div>

        {/* Annual Price Box */}
        <div
          className="w-1/2 p-4 flex flex-col items-start rounded-lg cursor-pointer transition-all duration-300"
          style={{
            backgroundColor: selectedPlan === "annual" ? ACTIVE_BG : LIGHT_BG,
            color: "black",
          }}
          onClick={() => setSelectedPlan("annual")}
        >
          <div className="flex items-center space-x-1 mb-1">
            <div className="w-4 h-4 rounded-full border border-black flex items-center justify-center">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: selectedPlan === "annual" ? "#FF6464" : LIGHT_BG,}}></div>
            </div>
            <span className="text-xs xl:text-sm font-bold">ANNUALLY</span>
          </div>
          <p className="text-lg xl:text-2xl font-bold">£11,440</p>
          <p className="text-xs">SAVE £500</p>
          <p className="text-xs">v's monthly price</p>
          <p className="text-xs">Pay in 2 x instalments</p>
        </div>

      </div>
      </>
      )}
    </div>
  );
};

export default PricingCartPriceToggle;
