primery color #FF6464
  const LIGHT_YELLOW = '#FFF1B0';
  const LIGHT_PINK = '#FFC0C0';